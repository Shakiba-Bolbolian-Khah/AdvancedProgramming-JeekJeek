#include "requestHandlers.hpp"


Response* ShowPage::callback(Request *req) {
    Response *res = new Response;
    res->setHeader("Content-Type", "text/html");
    string body = readFile(filePath.c_str());
    res->setBody(readFile(filePath.c_str()));
    return res;
}

Response* ShowImage::callback(Request *req) {
    Response *res = new Response;
    res->setHeader("Content-Type", "image/png");
    string body = readFile(filePath.c_str());
    res->setBody(body);
    return res;
}

Response *LoginHandler::callback(Request *req) {
	string sessionId;
    Response *res = new Response;
    string username = req->getBodyParam("username");
    string password = req->getBodyParam("password");
    cout << "Received Data: " << username << " - " << password << endl;
    res->setHeader("Content-Type", "text/html");
    try{
		sessionId = InterFace::management->login( username , password );





		vector < vector < string > > data(3);
    	data[0].push_back("hello world!");
    	data[1].push_back("theNewOne");
    	data[1].push_back("hashtags");
    	data[2].push_back("aaa");
    	InterFace::management->setCurUser( sessionId );
    	InterFace::management->add_jeek(data);
        vector < vector < string > > data2(3);
        data2[0].push_back("meeee is here at the hell!");
        data2[1].push_back("OneInThousand");
        data2[1].push_back("y");
        data2[2].push_back("shakiba");
        InterFace::management->add_jeek(data2);



	}
    catch(...){
	    res->setBody(readFile("htmlFiles/relogin.html"));
	    return res;
    }
    res->setBody(makeHomeHtml(sessionId));
    res->setSessionId(sessionId);
    return res;
}


Response * SignupHandler::callback(Request *req) {
    Response *res = new Response;
    string username = req->getBodyParam("username");
    string password = req->getBodyParam("password");
    string displayname = req->getBodyParam("displayname");
    cout << "Received Data: " << username << " - " << password << endl;
    res->setHeader("Content-Type", "text/html");
    try{
    	InterFace::management->signup( username , displayname , password );
    }
    catch(...){
	    res->setBody(readFile("htmlFiles/resignup.html"));	
	    return res;    	
    }
    res->setBody(readFile("htmlFiles/login.html"));
    return res;
}

Response* LogoutHandler::callback(Request *req){
	Response *res = new Response;
	string sessionId = req->getSessionId();
    res->setHeader("Content-Type", "text/html");
    InterFace::management->logout( sessionId );
    res->setBody(readFile("htmlFiles/login.html"));
    res->setSessionId("");
    return res;
}

Response* SearchHandler::callback(Request *req){
    Response *res = new Response;
    string sessionId = req->getSessionId();
    string searchText = req->getBodyParam("searchText");
    cout << "Received Data: " << searchText << endl;
    res->setHeader("Content-Type", "text/html");
    res->setBody(makeSearchHtml( searchText , sessionId ));
    return res;
}

Response* JeekHandler::callback(Request *req){
    Response *res = new Response;
    string _jeekId = req->getQueryParam("jeekId");
    string sessionId = req->getSessionId();
    jeekId = _jeekId;
    cout << "Received Data:" << _jeekId << endl;
    res->setHeader("Content-Type", "text/html");
    res->setBody(makeJeekHtml( sessionId ));
    return res;
}

Response* UserHomeHandler::callback(Request *req){
    Response *res = new Response;
    string sessionId = req->getSessionId();
    res->setHeader("Content-Type", "text/html");
    res->setBody(makeHomeHtml(sessionId));
    return res;  
}

Response* LikeHandler::callback(Request *req){
    Response *res = new Response;
    string sessionId = req->getSessionId();
    InterFace::management->handleLike( sessionId , jeekId );

    cout << "After Like!" << endl;

    res->setHeader("Content-Type", "text/html");
    res->setBody(makeJeekHtml( sessionId ));

    cout << makeJeekHtml(sessionId) << endl;

    return res;

}

string SearchHandler::makeSearchHtml( string searchText , string sessionId){
    string searchHtml = makeHtmlFile( searchText , true );
    InterFace::management->addSearchResult( searchText , searchHtml , sessionId);
    return searchHtml;
}

string JeekHandler::makeJeekHtml( string sessionId ){
    string jeekHtml = readFile("htmlFiles/jeekDetail.html");
    string username = InterFace::management->findUsername(sessionId);
    string displayname = InterFace::management->find_user(username)->get_displayname();
    int posOfDisplayname = jeekHtml.find('$');
    jeekHtml.replace(posOfDisplayname , 1, displayname );
    
    cout << "555" << endl;

    InterFace::management->find_jeek(jeekId)->addJeekInfo( jeekHtml , username );

    cout << ":))))))))))))))))";

    return jeekHtml;
}
