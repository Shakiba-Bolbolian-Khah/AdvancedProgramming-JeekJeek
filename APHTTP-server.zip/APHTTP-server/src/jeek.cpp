#include "jeek.hpp"
#include "user.hpp"

Jeek::Jeek(Content _content , User* _publisher , string _message_id ): Message(_content, _publisher, _message_id) {
	num_of_likes = 0 ;
	num_of_rejeeks = 0 ;
}


void Jeek::like( string liker_name ) {
	// if ( find_liker(liker_name) != -1 )
	// 	throw( Liked_Before() );
	num_of_likes++;
	likers.push_back( liker_name );
}

void Jeek::dislike( string disliker_name ) {
	// if ( find_liker(disliker_name) == -1 )
		// throw( No_Like_Before() );
	num_of_likes--;
	likers.erase( likers.begin() + find_liker(disliker_name) );
}

int Jeek::find_liker( string username ) {

	cout << "peydaaaaa konnnnnnnn!" << endl;
	cout << "sizeeee" << endl;
	// cout << likers.size() << endl;
	for (int i = 0 ; i < likers.size() ; i++ )
		if ( likers[i] == username )
			return i;
	cout << "dar haale peyda kardaan!!!!" << endl;
	return -1;
}

void Jeek::handleLike( string likerUsername ){

	cout << endl << "hereeeeee" << endl;
	// if( find_liker(likerUsername) == -1 ){
	// 	cout <<"OOnjaaaa" << endl;
	// 	like( likerUsername );
	// }
	// else{
	// 	cout <<"injaaaa" << endl;
	// 	dislike( likerUsername );
	// }
	cout << "--------------" << endl;
	// num_of_likes++;
	cout << endl << "***************/" << endl;
}

void Jeek::addJeekInfo( string &jeekHtml , string likerUsername ) {

	cout << "111" << endl;

	// cout<< "-----" << publisher->get_username() << endl;

	cout << "33333" << endl;

	// jeekHtml.replace( jeekHtml.find('*') , 1 , publisher->get_username() );
	
	cout << "222" << endl;

	jeekHtml.replace( jeekHtml.find("TEXT") , 4 , content.get_text());
	
	cout << "333" << endl;

	jeekHtml.replace( jeekHtml.find("TAGS") , 4 , content.get_tags());
	
	cout << "444" << endl;

	jeekHtml.replace( jeekHtml.find("MTNS") , 4 , content.get_mentions());
	
	cout << "555" << endl;

	jeekHtml.replace( jeekHtml.find('^') , 1 , to_string(num_of_likes) );
	
	cout << "666" << endl;

	jeekHtml.replace( jeekHtml.find('^') , 1 , to_string(num_of_rejeeks) );
	
	cout << "777" <<endl;

	if ( find_liker(likerUsername) == -1)
		jeekHtml.replace( jeekHtml.find('+') , 1 , "/dislike_logo");
	else
		jeekHtml.replace( jeekHtml.find('+') , 1 , "/like_logo");
}