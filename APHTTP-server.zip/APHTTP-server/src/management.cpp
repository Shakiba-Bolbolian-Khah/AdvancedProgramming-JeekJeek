#include "management.hpp"

void Management::signup( string username , string display_name , string password ) {
	if ( !check_username_repeat( username ) )
		throw(Repetitious_Username() );

	User* new_user = new User(username , display_name , password);
	users.push_back( new_user );
	return;
}

bool Management::check_username_repeat( string username ) {
	for (int i = 0 ; i < users.size() ; i++ )
		if ( users[i]->get_username() == username )
			return	false;
	return true;
}

User* Management::find_user( string username ) {
	for (int i = 0 ; i < users.size() ; i++ )
		if ( users[i]->get_username() == username )
			return users[i];
	return NULL;
}

string Management::login( string username , string password ) {
	User* found_user = find_user( username );
	if ( found_user == NULL )
		throw( User_Not_Found() );
	if ( found_user->get_password() == password ) {
		LoggedInUser newUser;
		string sessionId = makeSessionId();
		newUser.sessionId = sessionId ;
		newUser.loggedUser = found_user;
		loggedInUsers.push_back( newUser );
		cur_user = found_user;
		return sessionId;
	}
	else
		throw ( Wrong_Password() );
}

void Management::logout( string sessionId ) {
	if ( cur_user != NULL ) {
		int posOfUser = checkSessionRepeat( sessionId );
		if (posOfUser != -1 )
			loggedInUsers.erase(loggedInUsers.begin() + posOfUser);
		cur_user = NULL;
	}
}

void Management::add_jeek( vector < vector < string > > data ) {
	if (cur_user != NULL) {
		string jeek_id  = id_maker.make_id("J");
		cur_user->add_jeek(	data , jeek_id);
	}
}

vector<Jeek*> Management::search_user(string username ) {
	User* foundUser = find_user(username);
	if ( foundUser != NULL )
		return foundUser->get_jeeks();
}

vector<Jeek*> Management::search_hash_tags(string hash_tag ) {
	vector<Jeek*> searchResult;
	for (int i = 0 ; i < users.size() ; i++ )
		users[i]-> find_hash_tags(searchResult , hash_tag);
	return searchResult;
}

Jeek* Management::find_jeek(string jeek_id ) {
	for (int i = 0 ; i < users.size() ; i++ )
		if (users[i]->find_jeek(jeek_id) != NULL )
			return users[i]->find_jeek(jeek_id);
}

void Management::rejeek( string jeek_id ) {
	Jeek* found_jeek = find_jeek( jeek_id );
	if (found_jeek == NULL )
		throw( Message_Not_Found() );

	if (cur_user != NULL) {
		string rejeek_id = id_maker.make_id("J");
		if (cur_user->add_rejeek( found_jeek->get_text() , rejeek_id)) {
			found_jeek->increase_rejeeks();
		}
	}
}

void Management::like(string jeek_id) {
	Jeek* found_jeek = find_jeek(jeek_id);
	if (found_jeek == NULL )
		throw( Message_Not_Found() );

	if ( cur_user != NULL )
		found_jeek->like(cur_user->get_username());
}

void Management::dislike(string jeek_id) {
	Jeek* found_jeek = find_jeek(jeek_id);
	if (found_jeek == NULL )
		throw( Message_Not_Found() );

	if ( cur_user != NULL)
		found_jeek->dislike(cur_user->get_username());
}

string Management::makeSessionId() {
	srand(time(0));
	int newSessionId = rand() + 1 ;
	string sessionId = to_string( newSessionId );
	while ( checkSessionRepeat( sessionId ) != -1 ) {
		newSessionId = rand() + 1;
		sessionId = to_string( newSessionId );
	}

	return sessionId;
}

int Management::checkSessionRepeat(string newSessionId) {
	for ( int i = 0 ; i < loggedInUsers.size() ; i++ )
		if ( loggedInUsers[i].sessionId == newSessionId )
			return i;
	return -1;
}

void Management::setCurUser(string _sessionId ) {
	for ( int i = 0; i < loggedInUsers.size() ; i++ )
		if ( loggedInUsers[i].sessionId == _sessionId )
			cur_user = loggedInUsers[i].loggedUser;
}

int Management::returnNumOfJeeks( string username ) {
	User* found_user = find_user(username);
	return found_user->get_jeeks_size();
}

void Management::addUserInfo( string username , string &htmlFile ) {
	User* foundUser = find_user(username);
	foundUser->addUserInfo(htmlFile);
}

void Management::addData( vector<Jeek*> searchResult , string &htmlFile ) {
	for (int i = 0 ; i < searchResult.size() ; i++ ) {
		int posOfUsername = htmlFile.find("*");
		htmlFile.replace(posOfUsername , 1 , searchResult[i]->get_publisher_username() );
		int posOfJeekId = htmlFile.find("^");
		htmlFile.replace(posOfJeekId , 1 , searchResult[i]->get_id() );
		string jeekText = searchResult[i]->get_text() + searchResult[i]->get_tags();
		int posOfJeekText = htmlFile.find("$");
		htmlFile.replace(posOfJeekText , 1 , jeekText);
	}
}

void Management::addSearchResult(string searchExp , string &htmlFile , string sessionId ) {
	vector< Jeek* > searchResult;
	if (searchExp[0] == '#') {
		searchExp.erase( searchExp.begin() );
		searchResult = search_hash_tags( searchExp );
	}
	else if ( searchExp[0] == '@') {
		searchExp.erase( searchExp.begin() );
		searchResult = search_user(searchExp);
	}
	int posOfDisplayName = htmlFile.find("$");
	string displayname = loggedInUsers[checkSessionRepeat(sessionId)].loggedUser->get_displayname() ;
	htmlFile.replace(posOfDisplayName , 1 , displayname );
	addData( searchResult , htmlFile );
}

int Management::returnNumOfSearchResult( string searchExp ) {
	vector <Jeek*> results;
	results = search_hash_tags ( searchExp );

	return results.size();
}

string Management::findUsername( string sessionId ) {
	for ( int i = 0 ; i < loggedInUsers.size() ; i++ )
		if ( sessionId == loggedInUsers[i].sessionId )
			return loggedInUsers[i].loggedUser->get_username();
}

void Management::handleLike( string sessionId , string jeekId) {
	string likerUsername = findUsername(sessionId );
	find_jeek( jeekId )->handleLike( likerUsername );
	cout << "I amm hereee" << endl;
}