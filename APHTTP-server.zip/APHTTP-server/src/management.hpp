#ifndef _MANAGEMENT_H_
#define _MANAGEMENT_H_
#include <iostream>
#include <string>
#include <vector>
#include <cstdlib>
#include <time.h>
#include "user.hpp"
#include "jeek.hpp"
#include "message.hpp"
#include "id_maker.hpp"

using namespace std;

struct LoggedInUser{
	string sessionId;
	User* loggedUser;
};

class Management {
private:
	vector<User*> users;
	vector<LoggedInUser> loggedInUsers;
	User* cur_user;
	Id_Maker id_maker;

public:
	Management() { cur_user = NULL; }
	void setCurUser(string sessionId );
	void signup( string username , string display_name , string password );
	void logout( string sessionId);
	void add_jeek( vector < vector < string > > data );
	void rejeek( string jeek_id );
	void like(string jeek_id);
	void dislike(string jeek_id);
	void addUserInfo(string username , string &htmlFile );
	void addData( vector <Jeek*> searchResult , string &htmlFile );
	void addSearchResult(string searchExp , string &htmlFile , string sessionId);
	void handleLike( string sessionId , string jeekId );
	bool check_username_repeat( string username );
	int returnNumOfSearchResult( string searchExp );
	int checkSessionRepeat(string newSessionId);
	int returnNumOfJeeks( string username );
	string login( string username , string password );
	string makeSessionId();
	string makeHomeHtml(string username);
	string findUsername( string sessionId );
	vector<Jeek*> search_user(string username );
	vector<Jeek*> search_hash_tags(string hash_tag );
	Jeek* find_jeek(string jeek_id );
	User* find_user( string username );

};

#endif