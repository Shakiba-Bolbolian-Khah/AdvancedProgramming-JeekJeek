#include "message.hpp"
#include "user.hpp"

Message:: Message(Content _content , User* _publisher , string _message_id ) : content(_content){
	publisher = _publisher;
	message_id = _message_id;
}

bool Message::find_hash_tags(string hash_tag ){
	if (content.find_hash_tags(hash_tag))
		return true;
	else 
		return false;
}

string Message::get_publisher_username(){ return publisher->get_username() ;}