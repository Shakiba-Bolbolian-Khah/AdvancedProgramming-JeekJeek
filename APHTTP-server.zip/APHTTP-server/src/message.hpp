#ifndef _MESSAGE_H_
#define _MESSAGE_H_
#include <iostream>
#include <string>
#include <vector>
#include "content.hpp"
using namespace std;

class User;

class Message{
protected:
	string message_id;
	Content content;
	User* publisher;

public:
	Message(Content _content , User* _publisher , string _message_id );
	bool find_hash_tags(string hash_tag );
	string get_id(){ return message_id; }
	string get_text(){ return content.get_text(); }
	string get_tags(){ return content.get_tags(); }
	string get_publisher_username();
	User* get_publisher(){ return publisher; }
};


#endif