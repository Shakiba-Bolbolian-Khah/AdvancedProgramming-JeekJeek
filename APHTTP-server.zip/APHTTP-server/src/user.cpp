#include "user.hpp"

User::User(string _username , string _display_name , string _password ){
	username = _username;
	display_name = _display_name;
	password = _password;
}

void User::add_jeek( vector < vector < string > > data , string jeek_id ){
	if( data[0][0].size() > 140 ){
		throw( Bad_Jeek_Text_Size() );
	}

	Content new_content( data[0][0] , data[1] , data[2] );
	Jeek* new_jeek = new Jeek( new_content , this , jeek_id );
	jeeks.push_back(new_jeek);
}

void User::find_hash_tags(vector<Jeek*> &searchResult , string hash_tag ){
	for (int i = 0 ; i < jeeks.size() ; i++ )
		if( jeeks[i]->find_hash_tags(hash_tag) )
			searchResult.push_back(jeeks[i]);
}

Jeek* User::find_jeek( string jeek_id ){
	for( int i =0 ; i < jeeks.size() ; i++ ){
		if( jeeks[i]->get_id() == jeek_id )
			return jeeks[i];
	}
	return NULL;
}

bool User::add_rejeek( string text , string jeek_id ){
	string rejeek_text = "Rejeeked: " + text ;
	if ( rejeek_text.size() > 140 )
		throw(Bad_Jeek_Text_Size());

	Content rejeek_content(rejeek_text);
	Jeek* new_rejeek = new Jeek(rejeek_content , this , jeek_id );
	jeeks.push_back(new_rejeek);
	return true;
}

void User::addUserInfo(string &htmlFile ){
	int posOfDisplayName = htmlFile.find("$");
	htmlFile.replace(posOfDisplayName , 1 , display_name );
	for (int i = jeeks.size()-1 ; i >= 0 ; i-- ){
		int posOfUsername = htmlFile.find("*");
		htmlFile.replace(posOfUsername , 1 , username );
		int posOfJeekId = htmlFile.find("^");
		htmlFile.replace(posOfJeekId , 1 , jeeks[i]->get_id() );
		string jeekText = jeeks[i]->get_text() + jeeks[i]->get_tags();
		int posOfJeekText = htmlFile.find("$");
		htmlFile.replace(posOfJeekText , 1 , jeekText);
	}	
}