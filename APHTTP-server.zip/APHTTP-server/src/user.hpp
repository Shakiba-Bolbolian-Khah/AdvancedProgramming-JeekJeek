#ifndef _USER_H_
#define _USER_H_
#include <iostream>
#include <string>
#include <vector>
#include "message.hpp"
#include "jeek.hpp"
#include "error.hpp"
using namespace std;

class User{
private:
	string username;
	string display_name;
	string password;
	vector<Jeek*> jeeks;

public:
	User(string _username , string _display_name , string password );
	void add_jeek( vector < vector < string > > data , string jeek_id );
	bool add_rejeek( string text , string jeek_id );
	void find_hash_tags(vector<Jeek*> &searchResult , string hash_tag );
	int get_jeeks_size(){ return jeeks.size();}
	Jeek* find_jeek( string jeek_id );
	vector <Jeek*> get_jeeks(){ return jeeks; }
	string get_username(){ return username; }
	string get_password(){ return password; }
	string get_displayname(){ return display_name; }
	void addUserInfo(string &htmlFile );
};

#endif