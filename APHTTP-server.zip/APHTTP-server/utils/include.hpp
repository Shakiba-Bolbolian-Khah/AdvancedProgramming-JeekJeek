#ifndef __INCLUDE__
#define __INCLUDE__

enum Method { GET, POST };

#endif
